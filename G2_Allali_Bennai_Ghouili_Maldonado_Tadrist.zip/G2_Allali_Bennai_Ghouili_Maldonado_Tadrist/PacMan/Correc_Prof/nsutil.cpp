#include "nsutil.h"
#include "Correc_prof/params.h"

unsigned Rand ()
{
    return rand () % KNbCandies;
} // Rand ()
