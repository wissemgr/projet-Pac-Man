#ifndef GRIDMANAGEMENTV2_H
#define GRIDMANAGEMENTV2_H

/*!
 * @file gridmanagementV2.h
 * @brief Met en place des paramètres utiles pour le gridmanagement
 * @author Alain Casali
 * @author Marc Laporte
 * @version 1.0
 * @date 18 décembre 2018
 */


#include "Correc_Prof/type.h" //nos types


/**
 * @brief "Efface" le terminal actuel
 *  void ClearScreen ();
 */
void ClearScreen ();


/**
 * @brief Initialise la couleur de la future entrée dans le terminal
 * @param[in] Col : Nouvelle couleur à utiliser
 * @fn void Color (const std::string & Col);
 */

void Color (const std::string & Col);


/**
 * @brief Afficher la grille en fonction des paramètres
 * @param[in] Mat : Grille du jeu
 * @param[in] Params : : Liste de paramètres utiles
 * @fn void DisplayGrid (const CMat & Mat, const CMyParam & Params)
 * @version 1.0
 * @authors Alain Casali, Marc LaPorte
 */

void DisplayGrid (const CMat & Mat, const CMyParam & Params);


/*!
 * @brief Initialisation de la matrice à partir de zéro
 * @version 1.0
 * @authors Alain Casali, Marc LaPorte
 * @version 2.0
 * @author Maldonado Kevin
 * @author Ghouili Wissem
 * @author Bennai Yans
 * @param[in, out] Mat : la matrice à initialiser
 * @param[in] Parms : Met en place les paramètres du jeu
 * @param[out] PosPlayer1 : position du token du premier joueur dans Mat
 * @param[out] PosPlayer2 : position du token du deuxième joueur dans Mat
 * @fn void InitGrid (CMat & Mat, const CMyParam & Params, CPosition & PosPlayer1, CPosition & PosPlayer2);
 */

void InitGrid (CMat & Mat, const CMyParam & Params, CPosition & PosPlayer1, CPosition & PosPlayer2);

#endif // GRIDMANAGEMENTV2_H
