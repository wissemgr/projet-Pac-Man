#include <iostream>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <termios.h>
#include "gameV2.h"
#include "paramsV2.h"
#include "gridmanagementV2.h"
#include "Nos_fichiers/menu.h"
#include "Nos_fichiers/collision.h"
#include "Nos_fichiers/Classement.h"

#include <map>
using namespace std;
template <class T, class U>

void ShowMap (const map<T,U> & AMap){
    for (const pair <T,U> & Val : AMap)                cout << "Cle : " << Val.first << "  "             << "Valeur : " << Val.second << endl;
    cout << endl;
}// ShowMap ()

struct termios saved_attributes;

void reset_input_mode (void) //Désactive le mode non canonique
{
    tcsetattr (STDIN_FILENO, TCSANOW, &saved_attributes);
}

void set_input_mode (void) //Active le mode non canonique
{
    struct termios tattr;

    /* Make sure stdin is a terminal. */
    if (!isatty (STDIN_FILENO))
    {
        fprintf (stderr, "Not a terminal.\n");
        exit (EXIT_FAILURE);
    }

    /* Save the terminal attributes so we can restore them later. */
    tcgetattr (STDIN_FILENO, &saved_attributes);
    atexit (reset_input_mode);

    /* Set the funny terminal modes. */
    tcgetattr (STDIN_FILENO, &tattr);
    tattr.c_lflag &= ~(ICANON|ECHO); /* Clear ICANON and ECHO. */
    tattr.c_cc[VMIN] = 1;
    tattr.c_cc[VTIME] = 0;
    tcsetattr (STDIN_FILENO, TCSAFLUSH, &tattr);
}


void MoveToken (CMat & Mat, const char & Move, CPosition & Pos, unsigned & point)
{
    char car = Mat [Pos.first][Pos.second];
    Mat [Pos.first][Pos.second] = KEmpty;
    switch (Move)
    {
    case 'A':

        if (Pos.first == 0) {
            break;
        }
        else {
            -- Pos.first;
        }

        if (Pos.second == 0) {
            break;
        }
        else {
            -- Pos.second;
        }

        if(Mat[Pos.first][Pos.second] == '.')
        {
            ++point;

        }

        //ils sont considerés comme des obstacles et donc entrainent une collision
        if(Mat[Pos.first][Pos.second] == '#')
        {
            ++Pos.second;
            ++Pos.first;
            break;
        }

        if (Mat[Pos.first][Pos.second] == 'o')
        {
            ++Pos.second;
            ++Pos.first;
            break;
        }

        //Permet la téléportation
        if (Mat[Pos.first][Pos.second] == Mat[12][29]) {
            Pos.first = 2;
            Pos.second = 4;
            break;
        }

        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
        }

        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
        }
        break;
    case 'Z':

        if (Pos.first == 0) {
            Pos.first = Mat.size()-1;
            break;
        }

        //ils sont considerés comme des obstacles et donc entrainent une collision
        if(Mat[Pos.first-1][Pos.second] == '#')
        {
            break;
        }



        if(Mat[Pos.first-1][Pos.second] == 'o')
        {
            break;
        }

        else {
            --Pos.first;
        }

        if(Mat[Pos.first][Pos.second] == '.')
        {
            ++point;

        }

        //Permet la téléportation
        if (Mat[Pos.first][Pos.second] == Mat[12][29]) {
            Pos.first = 2;
            Pos.second = 4;
            break;
        }


        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
            break;
        }


        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
            break;
        }

        break;

    case 'E':
        if (Pos.first == 0) {
            break;
        }
        else {
            -- Pos.first;
        }

        if (Pos.second == Mat[Pos.first].size()-1) {
            break;
        }
        else {
            ++ Pos.second;
        }

        if(Mat[Pos.first][Pos.second] == '.')
        {
            ++point;

        }

        //ils sont considerés comme des obstacles et donc entrainent une collision
        if(Mat[Pos.first][Pos.second] == '#')
        {
            --Pos.second;
            ++Pos.first;
            break;
        }
        if(Mat[Pos.first][Pos.second] == 'o')
        {
            --Pos.second;
            ++Pos.first;
            break;
        }

        //Permet la téléportation
        if (Mat[Pos.first][Pos.second] == Mat[12][29]) {
            Pos.first = 2;
            Pos.second = 4;
            break;
        }


        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
        }

        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
        }

        break;
    case 'Q':

        if (Pos.second == 0) {
            Pos.second = Mat[Pos.first].size()-1;
            break;
        }

        //ils sont considerés comme des obstacles et donc entrainent une collision
        if(Mat[Pos.first][Pos.second-1] == '#')
        {

            break;
        }
        if(Mat[Pos.first][Pos.second-1] == 'o')
        {

            break;
        }

        else {
            --Pos.second;
        }

        if(Mat[Pos.first][Pos.second] == '.')
        {
            ++point;

        }

        //Permet la téléportation
        if (Mat[Pos.first][Pos.second] == Mat[12][29]) {
            Pos.first = 2;
            Pos.second = 4;
            break;
        }

        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
        }

        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
        }

        break;
    case 'D':

        if (Pos.second == Mat[Pos.first].size()-1) {
            Pos.second = 0;
            break;
        }

        //ils sont considerés comme des obstacles et donc entrainent une collision
        if(Mat[Pos.first][Pos.second+1] == '#')
        {

            break;
        }

        if(Mat[Pos.first][Pos.second+1] == 'o')
        {

            break;
        }

        else {
            ++Pos.second;
        }

        if(Mat[Pos.first][Pos.second] == '.')
        {
            ++point;

        }

        //Permet la téléportation
        if (Mat[Pos.first][Pos.second] == Mat[2][5]) {
            Pos.first = 12;
            Pos.second = 30;
            break;
        }


        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
        }

        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
        }



        break;
    case 'W':

        if (Pos.first == Mat.size()-1) {
            break;
        }
        else {
            ++ Pos.first;
        }

        if (Pos.second == 0) {
            break;

        }

        else {
            -- Pos.second;
        }

        if(Mat[Pos.first][Pos.second] == '.')
        {
            ++point;

        }

        //ils sont considerés comme des obstacles et donc entrainent une collision
        if(Mat[Pos.first][Pos.second] == '#')
        {
            ++Pos.second;
            --Pos.first;
            break;
        }
        if(Mat[Pos.first][Pos.second] == 'o')
        {
            ++Pos.second;
            --Pos.first;
            break;
        }

        //Permet la téléportation
        if (Mat[Pos.first][Pos.second] == Mat[2][5]) {
            Pos.first = 12;
            Pos.second = 30;
            break;
        }

        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
        }

        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
        }
        break;
    case 'S':

        if (Pos.first == Mat.size()-1) {
            Pos.first = 0;
            break;
        }

        //ils sont considerés comme des obstacles et donc entrainent une collision
        if(Mat[Pos.first+1][Pos.second] == '#')
        {

            break;
        }
        if(Mat[Pos.first+1][Pos.second] == 'o' )
        {

            break;
        }
        else {
            ++Pos.first;
        }

        if(Mat[Pos.first][Pos.second] == '.')
        {
            ++point;

        }

        //Permet la téléportation
        if (Mat[Pos.first][Pos.second] == Mat[2][5]) {
            Pos.first = 12;
            Pos.second = 30;
            break;
        }

        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
        }

        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
        }

        break;
    case 'C':

        if (Pos.first == Mat.size()-1) {
            break;
        }

        else {
            ++ Pos.first;
        }

        if (Pos.second == Mat[Pos.first].size()-1) {
            break;
        }

        else {
            ++ Pos.second;
        }

        if(Mat[Pos.first][Pos.second] == '.')
        {
            ++point;

        }

        //ils sont considerés comme des obstacles et donc entrainent une collision
        if(Mat[Pos.first][Pos.second] == '#')
        {
            --Pos.second;
            --Pos.first;
            break;
        }

        if(Mat[Pos.first][Pos.second] == 'o')
        {
            --Pos.second;
            --Pos.first;
            break;
        }

        //Permet la téléportation
        if (Mat[Pos.first][Pos.second] == Mat[2][5]) {
            Pos.first = 12;
            Pos.second = 30;
            break;
        }

        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
        }

        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
        }

        break;
    }
    Mat [Pos.first][Pos.second] = car;
} //MoveToken ()


bool PileouFace (unsigned valeur){ //Simulation d'un pile ou face
    bool resultat;
    unsigned cote;
    srand(time(NULL));
    cote = rand() % 2 + 1;
    if (valeur == cote)
    {
        resultat = true;
    }
    else {
        resultat = false;
    }
    return resultat;
} //PileouFace()

int ppal (void) // Mode de jeu 1 vs 1
{
    unsigned saisi(0);
    unsigned PartyNum (1);
    const unsigned KMaxPartyNum (400);
    CMat Mat;

    //Pile ou Face permettant de déterminer qui commence
    cout << "\033[H\033[2J";
    AfficheFich("CoinFlip.txt");
    cin >> saisi;
    bool Player1Turn (PileouFace(saisi));
    bool Victory (false);


    CPosition PosPlayer1, PosPlayer2;

    CMyParam Param;
    const string config = "../PacMan/Nos_fichiers/config.yaml";

    // Charge les paramètres de la map (fichier.yaml)
    int RetVal = LoadParams(Param, config);
    if (RetVal != 0)
    {
        return RetVal;
    }

    //Initialise et affhiche la map et les ennemies
    InitGrid(Mat, Param, PosPlayer1, PosPlayer2);
    DisplayGrid (Mat, Param);

    //Affiche le gagnant du pile ou face
    if(Player1Turn == true)
    {
        cout << "Bravo Joueur 1, vous avez gagné le pile ou face" <<endl;
    }
    else
    {
        cout << "Dommage Joueur 1, vous n'avez pas gagné le pile ou face" << endl;

    }

    //Permet l'asignation des pseudos
    string pseudo1;
    string pseudo2;
    cout << "Joueur 1 : Tapez votre pseudo " << endl;
    cin >> pseudo1;
    cout << "Joueur 2 : Tapez votre pseudo " << endl;
    cin >> pseudo2;

    unsigned point1 = 0;
    unsigned point2 = 0;
    while (PartyNum <= KMaxPartyNum && ! Victory)
    {

        cout << "tour numero : " << PartyNum << ", "
             << (Player1Turn ? point1: point2) << " point, "
             << (Player1Turn ? pseudo1 : pseudo2) << ", entrez un déplacement : "
             << endl;

        char Move= 'Y';

        //Active le mode non canonique
        set_input_mode();
        read(STDIN_FILENO, &Move, 1);

        Move = toupper (Move);

        //Mouvement des 2 joueurs, on alterne leurs nombres de points et tours respectifs selon qui joue
        MoveToken (Mat, Move, (Player1Turn ? PosPlayer1: PosPlayer2), (Player1Turn ? point1: point2));

        //Affiche la map
        ClearScreen();
        DisplayGrid (Mat, Param);

        //Condition de victoire
        if (PosPlayer1 == PosPlayer2 || point1 == 80 || point2 == 80) Victory = true;

        //Augmente le nombre de tours lorsqu'il y a un mouvement du joueur
        if(Move != 'Y')
            ++PartyNum;

        //Changement de tours de jeu entre les joueurs
        if(Move != 'Y')
            Player1Turn = !Player1Turn;
    }//while (no victory)

    if (!Victory)
    {
        //Enlève le mode non canonique
        reset_input_mode();

        Color (KColor.find("KMAgenta")->second);
        cout << "Aucun vainqueur" << endl;
        return 1;
    }
    //Enlève le mode non canonique
    reset_input_mode();

    Color (KColor.find("KGreen")->second);
    cout << "Félicitations Joueur" << (Player1Turn ? '2' : '1')
         << " vous avez gagné :)" << endl;
    Color (KColor.find("KReset")->second);

    //Inscrit dans un fichier txt le classement du meilleur joueur
    ChangClassement(PartyNum,(Player1Turn ? pseudo2 : pseudo1), (Player1Turn ? point2 : point1), "classement.txt");
    cout << "\033[H\033[2J";

    //Affiche le classement
    AfficheFich("classement.txt");
    return 0;
} //ppal ()
