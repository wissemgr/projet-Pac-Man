#ifndef PARAMSV2_H
#define PARAMSV2_H


/**
 * \file paramsV2.h
 * \brief Definition des paramètres et des fonctions associés
 * \author Alain Casali
 * \author Marc Laporte
 * \version 1.0
 * \date 18 décembre 2018
 */

#include "Correc_Prof/type.h"


/**
 * @brief Charge les paramètres du fichier YAML
 * @param[out] Param : Liste des paramètres utiles
 * @param[in] FileName : Chemin du fichier à charger
 * @fn void LoadParams (CMyParam & Param);
 * @return 0 si tout est bon, return erreur si le fichier ne peut pas se charger
 */

int LoadParams (CMyParam & Param, const std::string & FileName);

#endif // PARAMSV2_H
