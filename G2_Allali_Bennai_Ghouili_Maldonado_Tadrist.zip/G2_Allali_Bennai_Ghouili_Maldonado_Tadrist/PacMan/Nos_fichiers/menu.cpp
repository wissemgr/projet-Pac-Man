#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include "menu.h"
#include "Correc_V2/gameV2.h"
#include "Nos_fichiers/ModeIA/gameIA.h"

using namespace std;


void choix_couleur(string & couleur) //Permet de choisir la couleur du Joueur1
{

    unsigned choix;
    cout << "Joueur 1 : Choisissez votre couleur: ";
    cin >> choix;

    switch (choix)
    {
    case 1 :
        couleur = "KBlack";
        break;
    case 2 :
        couleur = "KRed";
        break;
    case 3 :
        couleur = "KGreen" ;
        break;
    case 4 :
        couleur = "KYellow" ;
        break;
    case 5 :
        couleur = "KBlue" ;
        break;
    case 6 :
        couleur = "KMagenta";
        break;
    case 7 :
        couleur = "KCyan";
        break;
    }
} //choix_couleur1 ()
void choix_couleur2(string & couleur) //Permet de choisir la couleur du Joueur 2
{

    unsigned choix;
    cout << "Joueur 2 : Choisissez votre couleur: ";
    cin >> choix;

    switch (choix)
    {
    case 1 :
        couleur = "KBlack";
        break;
    case 2 :
        couleur = "KRed";
        break;
    case 3 :
        couleur = "KGreen" ;
        break;
    case 4 :
        couleur = "KYellow" ;
        break;
    case 5 :
        couleur = "KBlue" ;
        break;
    case 6 :
        couleur = "KMagenta";
        break;
    case 7 :
        couleur = "KCyan";
        break;
    }
} //choix_couleur2 ()

void choixcarac (char & carac) //Permet de choisir entre les diférents caractères pour le Joueur 1
{
    unsigned choix;
    cout << "Joueur 1 : Choisissez votre charactère" << endl;
    cin >> choix;
    switch (choix)
    {
    case 1 :
        carac = 'X';
        break;
    case 2 :
        carac = 'O';
        break;
    case 3 :
        carac = '@';
        break;
    case 4 :
        carac = '$';
        break;
    case 5 :
        carac = '%';
        break;
    case 6 :
        carac = '+';
        break;

    }
} //choixcarac ()

void choixcarac2 (char & carac) //Permet de choisir entre les différents caractères pour le joueur 2
{
    unsigned choix;
    cout << "Joueur 2 : Choisissez votre charactère" << endl;
    cin >> choix;
    switch (choix)
    {
    case 1 :
        carac = 'X';
        break;
    case 2 :
        carac = 'O';
        break;
    case 3 :
        carac = '@';
        break;
    case 4 :
        carac = '$';
        break;
    case 5 :
        carac = '%';
        break;
    case 6 :
        carac = '+';
        break;

    }
} //choixcarac2 ()

void InitParam (const string & nomFichier) // Inialise les paramètres
{
    //Vérifi si n'est pas ouvert
    ofstream ofs(nomFichier);
    if (!ofs.is_open())
    {
        cout << "erreur" << endl;
        return;
    }
    //Configuration des touches de déplacement
    char Kup = 'z';
    char Kdown = 's';
    char Kleft = 'q';
    char Kright = 'd';

    //attribution des touches de déplacement
    ofs << "KeyUp : " << Kup << endl;
    ofs << "KeyDown : " << Kdown<< endl;
    ofs << "KeyLeft : " << Kleft<< endl;
    ofs << "KeyRight : " << Kright<< endl;

    ofs << "NbColumn : " << 15 << endl; //Dimension de la map
    ofs << "NbRow : " << 35 << endl; //Dimension de la map

    string couleur1;
    string couleur2;
    choix_couleur(couleur1);
    choix_couleur2(couleur2);
    ofs << "ColorP1 : " << couleur1 << endl;
    ofs << "ColorP2 :  " << couleur2 << endl;

    cout << "\033[H\033[2J";
    //Affiche le fichier cara.txt
    AfficheFich("carac.txt");
    //Déclaration de la variable du joueur 1
    char Token1 = 'O';
    //Déclaration de la variable du joueur 2
    char Token2 = 'X';
    choixcarac(Token1);
    choixcarac2(Token2);
    ofs << "TokenP1 : " << Token1<< endl;
    ofs << "TokenP2 : " << Token2<< endl;
}

void AfficheFich (const string & kfichier) // Affiche un fichier entré en paramètre
{
    // if (! ofs.is_open()){
    // cout << "Erreur" << endl;
    // return;
    ifstream texte (kfichier.c_str());
    if(texte.is_open() == true)
    {
        string ligne;
        while (getline(texte, ligne))
        {
            cout << ligne << endl;
        }
    }

    else
    {
        cout << "ERRUR AFFICHAGE" << endl;
    }
} //AfficheFich ()


int menu () { // int menu dans le projet (servira à choisir menu)
    AfficheFich("accueil.txt");
    cout << "choisir votre mode :  ";
    unsigned reponse=0;
    cin >> reponse;
    while (true)
    {
        // Choix du mode de jeu
        if (reponse == 1)
        {
            reponse = 0;
            while (reponse != 1 | reponse != 2){
                cout << "\033[H\033[2J";
                AfficheFich("Interface_mode_jeu.txt");
                cin >> reponse;

                //Choix du mode 1 VS 1
                if (reponse == 1){
                    try
                    {
                        return ppal ();
                    }
                    catch (...)
                    {
                        cerr << "ca c'est mal passe quelque part" << endl;
                        return 1;
                    }
                }
                //Choix du mode 1 VS IA
                if (reponse == 2){
                    try
                    {
                        return ppalIa ();
                    }
                    catch (...)
                    {
                        cerr << "ca c'est mal passe quelque part" << endl;
                        return 1;
                    }
                }

            }
        }
        //Choix du mode paramètres
        if (reponse == 2)
        {
            cout << "\033[H\033[2J";
            AfficheFich("couleur.txt");
            InitParam("../PacMan/Nos_fichiers/config.yaml");
            try
            {
                return ppal ();
            }
            catch (...)
            {
                cerr << "ca c'est mal passe quelque part" << endl;
                return 1;
            }
        }
        //Choix du mode classement
        if (reponse == 3)
        {
            reponse = 0;
            cout << "\033[H\033[2J";
            cout << "Classement de la partie précédente" << endl;
            AfficheFich("classement.txt");
            cout << "[1] Retour Au Menu |" << "| [2] Quitter Le Jeu" << endl;
            cin >> reponse;
            if (reponse == 1){
                cout << "\033[H\033[2J";
                try
                {
                    return menu ();
                }
                catch (...)
                {
                    cerr << "ca c'est mal passe quelque part" << endl;
                    return 1;
                }
            }
            else{
                exit(0);
            }
        }
        //Choix du mode règles
        if (reponse == 4){
            reponse = 0;
            cout << "\033[H\033[2J";
            AfficheFich("regles.txt");
            cin >> reponse;
            //Jouer en 1 VS 1
            if (reponse == 1){
                try
                {
                    return ppal ();
                }
                catch (...)
                {
                    cerr << "ca c'est mal passe quelque part" << endl;
                    return 1;
                }
            }
            //Jouer en 1 VS IA
            if (reponse == 2){
                try
                {
                    return ppalIa ();
                }
                catch (...)
                {
                    cerr << "ca c'est mal passe quelque part" << endl;
                    return 1;
                }
            }
            //Retour menu
            if (reponse == 3){
                cout << "\033[H\033[2J";
                try
                {
                    return menu ();
                }
                catch (...)
                {
                    cerr << "ca c'est mal passe quelque part" << endl;
                    return 1;
                }
            }
            else{
                exit(0);
            }
        }
        else {
            exit(0);
        }
        return 0;
    }
} //menu ()
