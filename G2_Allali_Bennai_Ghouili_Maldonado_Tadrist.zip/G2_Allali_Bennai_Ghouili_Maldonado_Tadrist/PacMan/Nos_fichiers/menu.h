#ifndef MENU_H
#define MENU_H

/*!
 * @file menu.h
 * @brief Affiche le menu principal du jeu et les autres menus
 * @author Maldonado Kevin
 * @author Bennai Yanis
 * @author Ghouili Wissem
 * @version 1.0
 * @date 05 janvie 2021
 */

int menu();

/**
 * @brief Choisis la couleur que le joueur 1 choisis en paramètre
 * @author Ghouili Wissem
 * @param[out] couleur : la couleur que le joueur 1 a choisis
 * @fn void piece (CMat & Mat);
 * @version 1.0
 * @date 20 janvier 2021
 */

#include <string>

void choix_couleur(std::string & couleur);


/**
 * @brief Choisis la couleur que le joueur 2 choisis en paramètre
 * @author Ghouili Wissem
 * @param[out] couleur : la couleur que le joueur 2 a choisis
 * @fn void choix_couleur2(std::string & couleur);
 * @version 1.0
 * @date 20 janvier 2021
 */

void choix_couleur2(std::string & couleur);


/**
 * @brief Choisis le personnage que le joueur 1 choisis en paramètre
 * @author Ghouili Wissem
 * @param[out] carac : le caractère que le joueur 1 a choisis
 * @fn void choixcarac (char & carac);
 * @version 1.0
 * @date 21 janvier 2021
 */

void choixcarac (char & carac);


/**
 * @brief Choisis le personnage que le joueur 2 choisis en paramètre
 * @author Ghouili Wissem
 * @param[out] carac : le caractère que le joueur 2 a choisis
 * @fn void choixcarac2 (char & carac);
 * @version 1.0
 * @date 21 janvier 2021
 */

void choixcarac2 (char & carac);


/**
 * @brief Met en place les paramètres choisis par les joueurs dans le fichier YAML
 * @author Ghouili Wissem
 * @param[in] nomfichier : le fichier YAML où l'on va modifier les paramètres
 * @fn void InitParam (const std::string & monFichier);
 * @version 2.0
 * @date 19 janvier 2021
 */

void InitParam (const std::string & nomFichier);


/**
 * @brief Affiche le fichier mis en paramètre
 * @author Ghouili Wissem
 * @author Maldonado Kevin
 * @param[in] kfichier : le fichier qu'on souhaite afficher
 * @fn void AfficheFich (const std::string & kfichier);
 * @version 1.0
 * @date 12 janvier 2021
 */

void AfficheFich (const std::string & kfichier);



#endif // MENU_H
