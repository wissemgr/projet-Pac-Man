#ifndef TYPEIA_H
#define TYPEIA_H

/*!
 * \file typeIA.h
 * \brief Définition des types d'alias utiles pour le projet
 * \author Maldonado Kevin
 * \version 2.0
 * \date 20 janvier 2021
 */

#include <string>
#include <vector>
#include <map>


/**
 * @brief Structure contenant toutes les clés autorisées dans la structure CMyParam
 */

struct AuthorizedKeyIA {
    /** Liste des clés autorisées pour le type char dans une structure CMyParam*/
    const std::vector <std::string> VParamCharIA {"KeyUp", "KeyDown", "KeyLeft", "KeyRight", "TokenP1", "IaP1", "IaP2", "IaP3", "IaP4"};
    /** Liste des clés autorisées pour le type string dans une structure CMyParam*/
    const std::vector <std::string> VParamStringIA {"ColorTokenP1", "ColorIaP1", "ColorIaP2", "ColorIaP3", "ColorIaP4"};
    /** Liste des clés autorisées pour le type unsigned dans une structure CMyParam*/
    const std::vector <std::string> VParamUnsignedIA {"NbRow", "NbColumn"};
};

/**
 * @brief KAuthorizedKeyIA
 */
const AuthorizedKeyIA KAuthorizedKeyIA;


#endif // TYPEIA_H
