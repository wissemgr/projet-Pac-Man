#include <iostream>
#include <iomanip>
#include "Correc_Prof/type.h"
#include "Nos_fichiers/collision.h"
#include "Nos_fichiers/ModelIA_LVL2/paramsIA_LVL2.h"
#include "Nos_fichiers/ModelIA_LVL2/gridmanagementIA_LVL2.h"
#include "Nos_fichiers/Correc_V2/gridmanagementV2.h"


using namespace std;

void DisplayGridIa_LVL2 (const CMat & Mat, const CMyParam & Param)
{
    ClearScreen ();
    Color (KColor.find("KReset")->second);
    const unsigned KNbLine = Mat.size ();
    const unsigned KNbCol  = Mat[0].size ();
    cout << string (KNbCol + 2 , '-') << endl;
    for (unsigned i (0); i < KNbLine; ++i)
    {
        cout << '|';
        for (unsigned j (0); j < Mat[i].size(); ++j)
        {
            if (Param.MapParamChar.find("TokenP1")->second ==  Mat[i][j])
                Color (Param.MapParamString.find("ColorTokenP1")->second );
            else if (Param.MapParamChar.find("IaP1")->second == Mat[i][j])
                Color (Param.MapParamString.find("ColorIaP1")->second );
            else if (Param.MapParamChar.find("IaP2")->second == Mat[i][j])
                Color (Param.MapParamString.find("ColorIaP2")->second );
            else if (Param.MapParamChar.find("IaP3")->second == Mat[i][j])
                Color (Param.MapParamString.find("ColorIaP3")->second );
            else if (Param.MapParamChar.find("IaP4")->second == Mat[i][j])
                Color (Param.MapParamString.find("ColorIaP4")->second );
            else if (Param.MapParamChar.find("IaP5")->second == Mat[i][j])
                Color (Param.MapParamString.find("ColorIaP5")->second );
            else if (Param.MapParamChar.find("IaP6")->second == Mat[i][j])
                Color (Param.MapParamString.find("ColorIaP6")->second );
            else if (Param.MapParamChar.find("IaP7")->second == Mat[i][j])
                Color (Param.MapParamString.find("ColorIaP7")->second );
            else
                Color (KColor.find("KReset")->second);
            cout << Mat[i][j];
            Color (KColor.find("KReset")->second);

        }
        cout << '|' << endl;
    }
    cout << string (KNbCol + 2 , '-') << endl;
}// DisplayGridIa_LVL2 ()

void InitGridIa_LVL2 (CMat & Mat, const CMyParam & Params, CPosition & PosPlayer1, CPosition & PosIa1, CPosition & PosIa2,
                      CPosition & PosIa3, CPosition & PosIa4, CPosition & PosIa5, CPosition & PosIa6, CPosition & PosIa7)
{
    Mat.resize (Params.MapParamUnsigned.find("NbColumn")->second);
    const CVLine KLine (Params.MapParamUnsigned.find("NbRow")->second, KEmpty);
    for (CVLine &ALine : Mat)
        ALine = KLine;

    //Mettre fonction qui modifie la map
    Mat[2][5] = '>';
    Mat[12][29] = '<';
    Mat[10][3] = '^';
    Mat[4][31] = 'v';
    Mat[7][17] = 'o';
    mur(Mat);
    piece (Mat);

    //Définit les endroits d'apparition des entités
    PosPlayer1.first = 1;
    PosPlayer1.second = Params.MapParamUnsigned.find("NbRow")->second - 2;
    Mat [PosPlayer1.first][PosPlayer1.second] = Params.MapParamChar.find("TokenP1")->second;
    PosIa1.first = Params.MapParamUnsigned.find("NbColumn")->second - 8;
    PosIa1.second = 13;
    Mat [PosIa1.first][PosIa1.second] = Params.MapParamChar.find("IaP1")->second;
    PosIa2.first = Params.MapParamUnsigned.find("NbColumn")->second - 6;
    PosIa2.second = 17;
    Mat [PosIa2.first][PosIa2.second] = Params.MapParamChar.find("IaP2")->second;
    PosIa3.first = Params.MapParamUnsigned.find("NbColumn")->second - 8;
    PosIa3.second = 21;
    Mat [PosIa3.first][PosIa3.second] = Params.MapParamChar.find("IaP3")->second;
    PosIa4.first = Params.MapParamUnsigned.find("NbColumn")->second - 10;
    PosIa4.second = 17;
    Mat [PosIa4.first][PosIa4.second] = Params.MapParamChar.find("IaP4")->second;
    PosIa5.first = Params.MapParamUnsigned.find("NbColumn")->second - 2;
    PosIa5.second = 1;
    Mat [PosIa5.first][PosIa5.second] = Params.MapParamChar.find("IaP5")->second;
    PosIa6.first = Params.MapParamUnsigned.find("NbColumn")->second - 2;
    PosIa6.second = 33;
    Mat [PosIa6.first][PosIa6.second] = Params.MapParamChar.find("IaP6")->second;
    PosIa7.first = Params.MapParamUnsigned.find("NbColumn")->second - 14;
    PosIa7.second = 1;
    Mat [PosIa7.first][PosIa7.second] = Params.MapParamChar.find("IaP7")->second;
} // InitGridIa_LVL2 ()
