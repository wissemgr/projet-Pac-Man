#include <string>
#include <fstream>
#include <iostream>
#include <algorithm>
#include "paramsIA_LVL2.h"


using namespace std;

int LoadParamsIA_LVL2 (CMyParam & Param, const std::string & FileName)
{
    ifstream ifs (FileName);
    if (!ifs.is_open())
    {
        cerr << "pas le bon fichier de configuration";
        return 2;
    }
    string Key;
    while (ifs >> Key)
    {
        char tmp;
        ifs >> tmp;
        if (find (KAuthorizedKeyIA_LVL2.VParamCharIA_LVL2.begin(), KAuthorizedKeyIA_LVL2.VParamCharIA_LVL2.end(), Key) != KAuthorizedKeyIA_LVL2.VParamCharIA_LVL2.end())
            ifs >> Param.MapParamChar[Key];
        else if (find (KAuthorizedKeyIA_LVL2.VParamUnsignedIA_LVL2.begin(), KAuthorizedKeyIA_LVL2.VParamUnsignedIA_LVL2.end(), Key) != KAuthorizedKeyIA_LVL2.VParamUnsignedIA_LVL2.end())
            ifs >> Param.MapParamUnsigned[Key];
        else if (find (KAuthorizedKeyIA_LVL2.VParamStringIA_LVL2.begin(), KAuthorizedKeyIA_LVL2.VParamStringIA_LVL2.end(), Key) != KAuthorizedKeyIA_LVL2.VParamStringIA_LVL2.end())
        {
            string Val;
            ifs >> Val;
            Param.MapParamString[Key] = KColor.find(Val)->second;
        }
    }
    return 0;
} //LoadParamsIA()
