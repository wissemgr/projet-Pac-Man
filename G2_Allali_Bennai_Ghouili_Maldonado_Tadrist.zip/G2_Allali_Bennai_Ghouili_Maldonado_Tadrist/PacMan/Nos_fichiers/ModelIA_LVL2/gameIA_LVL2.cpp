#include <iostream>
#include <termios.h>
#include <unistd.h>
#include "Correc_Prof/type.h"
#include "Nos_fichiers/Correc_V2/gameV2.h"
#include "Nos_fichiers/ModelIA_LVL2/typeIA_LVL2.h"
#include "Nos_fichiers/ModelIA_LVL2/gridmanagementIA_LVL2.h"
#include "Nos_fichiers/ModelIA_LVL2/paramsIA_LVL2.h"
#include "Nos_fichiers/ModelIA_LVL2/gameIA_LVL2.h"
#include "Nos_fichiers/ModeIA/gameIA.h"
#include "Nos_fichiers/Correc_V2/gridmanagementV2.h"
#include "Nos_fichiers/menu.h"


using namespace std;

int ppalIa_LVL2 (void) // Deuxième niveau du mode de jeu 1 vs IA
{
    unsigned PartyNum (1);
    const unsigned KMaxPartyNum (225);
    CMat Mat;
    bool Victory (false);
    bool VictoryPoint (false);

    CPosition PosPlayer1, PosIa1, PosIa2, PosIa3, PosIa4, PosIa5, PosIa6, PosIa7;

    CMyParam Param;

    // Charge les paramètres de la map (fichier.yaml)
    const string config = "../PacMan/Nos_fichiers/configIA_LVL2.yaml";
    int RetVal = LoadParamsIA_LVL2(Param, config);
    if (RetVal != 0)
    {
        return RetVal;
    }

    //Initialise et affhiche la map et les ennemies
    InitGridIa_LVL2 (Mat, Param, PosPlayer1, PosIa1, PosIa2, PosIa3, PosIa4, PosIa5, PosIa6, PosIa7);
    DisplayGridIa_LVL2 (Mat, Param);

    //Active le mode non canonique
    set_input_mode();

    unsigned point1 (0);
    while (PartyNum <= KMaxPartyNum && ! Victory)
    {
        cout << "tour numero : " << PartyNum << ", " << point1 << "point" << ", Joueur 1"
             << ", entrez un déplacement : "
             << endl;

        //Rend aléatoire les mouvements des IA
        unsigned MovRand;
        srand(time(NULL));
        MovRand = rand() % 8 + 1;
        MouveEnnemies(Mat, MovRand, PosIa1);

        MovRand = rand() % 8 + 1;
        MouveEnnemies(Mat, MovRand, PosIa2);

        MovRand = rand() % 8 + 1;
        MouveEnnemies(Mat, MovRand, PosIa3);

        MovRand = rand() % 8 + 1;
        MouveEnnemies(Mat, MovRand, PosIa4);

        MovRand = rand() % 8 + 1;
        MouveEnnemies(Mat, MovRand, PosIa5);

        MovRand = rand() % 8 + 1;
        MouveEnnemies(Mat, MovRand, PosIa6);

        MovRand = rand() % 8 + 1;
        MouveEnnemies(Mat, MovRand, PosIa7);

        char Move= 'Y';

        read(STDIN_FILENO, &Move, 1);

        Move = toupper (Move);
        MoveToken (Mat, Move, PosPlayer1, point1);

        ClearScreen();
        DisplayGridIa_LVL2 (Mat, Param);

        //Teste de défaite, vérification si le joueur est sur l'emplacement des ennemies
        if (PosPlayer1 == PosIa1 || PosIa1 == PosPlayer1) Victory = true;
        if (PosPlayer1 == PosIa2 || PosIa2 == PosPlayer1) Victory = true;
        if (PosPlayer1 == PosIa3 || PosIa3 == PosPlayer1) Victory = true;
        if (PosPlayer1 == PosIa4 || PosIa4 == PosPlayer1) Victory = true;
        if (PosPlayer1 == PosIa5 || PosIa5 == PosPlayer1) Victory = true;
        if (PosPlayer1 == PosIa6 || PosIa6 == PosPlayer1) Victory = true;
        if (PosPlayer1 == PosIa7 || PosIa7 == PosPlayer1) Victory = true;

        //Teste de victoire, vérification si le joueur a atteint le nombre de point nécessaire
        if (point1 == 90){
            VictoryPoint = true;
            break;
        }

        //Augmente le nombre de tours lorsqu'il y a un mouvement du joueur
        if(Move != 'Y')
            ++PartyNum;
    }//while (no victory)

    if (!Victory | VictoryPoint)
    {
        //Enleve le mode non canonique
        reset_input_mode();

        Color (KColor.find("KGreen")->second);
        cout << "Bravo vous avez gagné"<< endl;
        return 1;
    }
    //Enleve le mode non canonique
    reset_input_mode();
    ClearScreen();
    AfficheFich("game_over.txt");

    cout << "Vous vous êtes fait mangé par un fantôme"
         << " vous avez perdu :(" << endl;
    Color (KColor.find("KReset")->second);
    return 0;
} //ppalIa_LVL2 ()
