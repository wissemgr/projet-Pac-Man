#ifndef PARAMSIA_LVL2_H
#define PARAMSIA_LVL2_H

/**
 * @file paramsIA_LVL2.h
 * @brief Définition des paramètres et des fonctions associés
 * @author Alain Casali
 * @author Marc Laporte
 * @version 1.0
 * @date 18 décembre 2018
 */

#include "Correc_Prof/type.h"

/**
 * @file paramsIA_LVL2.h
 * @brief Définition des paramètres et des fonctions associés pour l'intelligence artificielle
 * @author Kevin Maldonado
 * @version 2.0
 * @date 20 janvier 2021
 */

#include "Nos_fichiers/ModelIA_LVL2/typeIA_LVL2.h"

/**
 * @brief Charge les paramètres du fichier YAML
 * @version 3.0
 * @author Maldonado Kevin
 * @param[out] Param : Liste des paramètres utiles
 * @param[in] FileName : Chemin du fichier à charger
 * @fn int LoadParamsIA_LVL2 (CMyParam & Param, const std::string & FileName);
 * @return 0 si tout est bon, return erreur si le fichier ne peut pas se charger
 * @date 21 janvier 2021
 */

int LoadParamsIA_LVL2 (CMyParam & Param, const std::string & FileName);

#endif // PARAMSIA_LVL2_H
