#ifndef GAMEIA_LVL2_H
#define GAMEIA_LVL2_H

/**
  * @file gameIA_LVL2.h
  */

/**
 * @brief lance le jeu 1 VS IA (Niveau 2)
 * @version 3.0
 * @author Maldonado Kevin
 * @return 0 si tout est bon
 * @fn int ppalIa_LVL2 (void);
 * @date 21 janvier 2020
 */

int ppalIa_LVL2 (void);

#endif // GAMEIA_LVL2_H
