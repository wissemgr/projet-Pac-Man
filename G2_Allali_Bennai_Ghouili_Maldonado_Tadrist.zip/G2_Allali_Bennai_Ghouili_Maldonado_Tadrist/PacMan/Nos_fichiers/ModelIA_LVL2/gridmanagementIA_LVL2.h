#ifndef GRIDMANAGEMENTIA_LVL2_H
#define GRIDMANAGEMENTIA_LVL2_H

/*!
 * @file gridmanagementIA_LVL2.h
 * @brief Met en place des paramètres utiles pour le gridmanagementIA_LVL2
 * @author Alain Casali
 * @author Marc Laporte
 * @version 1.0
 * @date 18 décembre 2018
 */

#include "Correc_Prof/type.h"

/**
 * @brief Affiche la grille en fonction des paramètres
 * @author Maldonado Kevin
 * @param[in] Mat : Grille du jeu
 * @param[in] Params : : Liste de paramètres utiles
 * @fn void DisplayGridIa_LVL2 (const CMat & Mat, const CMyParam & Param);
 * @version 3.0
 * @date 21 janvier 2021
 */

void DisplayGridIa_LVL2 (const CMat & Mat, const CMyParam & Param);

/*!
 * @brief Initialisation de la matrice à partir de zéro
 * @author Maldonado Kevin
 * @param[out] Mat la matrice à initialiser
 * @param[in] Params Met en place les paramètres du jeu
 * @param[out] PosPlayer1 position du premier joueur dans Mat
 * @param[out] PosIa1 position de l'IA numero 1 dans Mat
 * @param[out] PosIa2 position de l'IA numero 2 dans Mat
 * @param[out] PosIa3 position de l'IA numero 3 dans Mat
 * @param[out] PosIa4 position de l'IA numero 4 dans Mat
 * @param[out] PosIa5 position de l'IA numero 5 dans Mat
 * @param[out] PosIa6 position de l'IA numero 6 dans Mat
 * @param[out] PosIa7 position de l'IA numero 7 dans Mat
 * @fn void InitGridIa_LV2 (CMat & Mat, const CMyParam & Params, CPosition & PosPlayer1, CPosition & PosIa1, CPosition & PosIa2, CPosition & PosIa3, CPosition & PosIa4, CPosition & PosIa5, CPosition & PosIa6, CPosition & PosIa7);
 * @version 3.0
 * @date 21 janvier 2021
 */

void InitGridIa_LVL2 (CMat & Mat, const CMyParam & Params, CPosition & PosPlayer1, CPosition & PosIa1, CPosition & PosIa2,
                      CPosition & PosIa3, CPosition & PosIa4, CPosition & PosIa5, CPosition & PosIa6, CPosition & PosIa7);

#endif // GRIDMANAGEMENTIA_LVL2_H
