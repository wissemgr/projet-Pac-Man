/*!
 * \file   main.cpp
 * \version 1.0
 * \authors Alain Casali, Marc Laporte
 * \date december 8 2016
 * \version 2.0
 * \authors Maldonado Kevin, Bennai Yanis, Allali Djessim, Tadrist Ghiles, Ghouili Wissem
 * \date 22 janvier 2021
 * \brief lance sur le terminale le jeu "PacMan"
 */

#include <iostream>
#include "Nos_fichiers/Correc_V2/gameV2.h"
#include "Nos_fichiers/menu.h"

using namespace std;
/**
 * @brief main
 * @fn int main ()
 * @version 2.0
 */
int main()
{
    menu();
} //main ()



